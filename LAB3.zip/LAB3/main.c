// -----------------------------------------------------------------------------
// Programa: Emisor visual simplificado con recuadro fijo y menú de token (X11, Linux)
// Autor:    Grok 4 (basado en código original)
// Propósito:
//   - Abre una ventana y dibuja un recuadro fijo en la esquina superior derecha.
//   - Genera un patrón visual: pulso de sincronismo (parpadeo blanco/negro) y bits del tiempo.
//   - Muestra un menú simple para ingresar un TOKEN (6 dígitos) y verificar si es válido.
//   - Código acortado, simplificado y comentado completamente.
//   - Parpadeo inicia limpio (caja en negro al empezar).
// -----------------------------------------------------------------------------

#include <X11/Xlib.h>    // Para funciones de X11
#include <X11/keysym.h>  // Para símbolos de teclas
#include <stdio.h>       // Para entrada/salida estándar
#include <stdlib.h>      // Para funciones generales (exit, atoi)
#include <string.h>      // Para manejo de strings (strcpy, strlen)
#include <unistd.h>      // Para usleep (en lugar de nanosleep para simplicidad)
#include <time.h>        // Para time y clock_gettime

// -------------------------------
// Parámetros de ventana y recuadro (fijo en esquina superior derecha)
// -------------------------------
#define WIN_W 800        // Ancho de ventana
#define WIN_H 600        // Alto de ventana
#define BOX_W 200        // Ancho de recuadro
#define BOX_H 200        // Alto de recuadro
#define BOX_X (WIN_W - BOX_W - 20)  // Posición X: esquina derecha con margen
#define BOX_Y 20         // Posición Y: esquina superior con margen

// -------------------------------
// Tiempos de pulsos en ms (simplificados)
// -------------------------------
#define PULSE_SYNC 100   // Duración total de sincronismo
#define PULSE_BLINK 50   // Periodo de parpadeo en sincronismo (mitad para blanco/negro)
#define PULSE_BIT 100    // Duración de bit (igual para 0 y 1, pero distinguido por longitud efectiva)
#define PULSE_SEP 100    // Separador entre bits

// -------------------------------
// Estados de la UI (simplificados)
// -------------------------------
typedef enum {
    UI_IDLE,     // Esperando input
    UI_SENDING,  // Enviando patrón
    UI_TOKEN     // Ingresando token
} ui_state_t;

// -------------------------------
// Variables globales mínimas
// -------------------------------
unsigned int bits[32];       // Bits del tiempo a enviar
int bit_index = 0;           // Índice actual de bit
int sending = 0;             // Flag de envío activo
int stage = 0;               // Etapa: 0=sync, 1=bits
unsigned long start_ms = 0;  // Tiempo de inicio de segmento
int box_on = 0;              // Estado de caja: 0=negro, 1=blanco (inicia en negro)
ui_state_t state = UI_IDLE;  // Estado inicial: idle
char token[7] = {0};         // Buffer para token (6 dígitos + null)
int tok_len = 0;             // Longitud actual de token
char msg[128] = "Presiona ENTER para enviar";  // Mensaje de estado

// -------------------------------
// Tiempo actual en ms (monotónico)
// -------------------------------
unsigned long now_ms() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000ul + ts.tv_nsec / 1000000ul;
}

// -------------------------------
// Convierte entero a bits (32 bits)
// -------------------------------
void int_to_bits(unsigned int val) {
    for (int i = 0; i < 32; i++) {
        bits[i] = (val >> (31 - i)) & 1;
    }
    bit_index = 0;
}

// -------------------------------
// Genera token hash simple
// -------------------------------
unsigned int make_token(unsigned int t) {
    unsigned int h = t ^ 0xA5A5A5A5u;
    h ^= (h >> 16);
    h *= 0x45d9f3bu;
    h ^= (h >> 16);
    h *= 0x45d9f3bu;
    h ^= (h >> 16);
    return h % 1000000u;
}

// -------------------------------
// Prepara transmisión (inicia sync en negro)
// -------------------------------
void prepare_tx() {
    unsigned int t = (unsigned int)(time(NULL) / 30u);
    int_to_bits(t);
    sending = 1;
    stage = 0;
    start_ms = now_ms();
    box_on = 0;  // Inicia en negro para parpadeo limpio
    strcpy(msg, "Enviando...");
    state = UI_SENDING;
}

// -------------------------------
// Dibuja ventana y elementos
// -------------------------------
void draw(Display *d, Window w, GC gc) {
    XSetForeground(d, gc, BlackPixel(d, DefaultScreen(d)));
    XFillRectangle(d, w, gc, 0, 0, WIN_W, WIN_H);  // Fondo negro

    // Dibuja caja: blanco si on, negro si off
    XSetForeground(d, gc, box_on ? WhitePixel(d, DefaultScreen(d)) : BlackPixel(d, DefaultScreen(d)));
    XFillRectangle(d, w, gc, BOX_X, BOX_Y, BOX_W, BOX_H);

    // Mensaje de estado
    XSetForeground(d, gc, 0x00FF00);  // Verde
    XDrawString(d, w, gc, 20, 20, msg, strlen(msg));

    // Instrucciones según estado
    if (state == UI_TOKEN) {
        char buf[64];
        snprintf(buf, sizeof(buf), "TOKEN: %s", token);
        XDrawString(d, w, gc, 20, 50, buf, strlen(buf));
        XDrawString(d, w, gc, 20, 80, "6 digitos, ENTER=validar, ESC=reset", 36);
    } else if (state == UI_IDLE) {
        XDrawString(d, w, gc, 20, 50, "ENTER=enviar | Q=salir", 22);
    }
}

// -------------------------------
// Avanza patrón de transmisión
// -------------------------------
void step_pattern() {
    if (!sending) return;
    unsigned long t = now_ms();
    unsigned long elapsed = t - start_ms;

    if (stage == 0) {  // Sync: parpadeo
        if (elapsed < PULSE_SYNC) {
            box_on = ((elapsed / PULSE_BLINK) % 2) == 0 ? 1 : 0;
        } else {
            box_on = 0;
            stage = 1;
            start_ms = t;
        }
    } else if (stage == 1) {  // Bits
        if (bit_index < 32) {
            int bit = bits[bit_index];
            unsigned long pulse = bit ? PULSE_BIT : PULSE_BIT / 2;  // Simplificado: bit1 largo, bit0 corto
            if (elapsed < pulse) {
                box_on = 1;
            } else if (elapsed < pulse + PULSE_SEP) {
                box_on = 0;
            } else {
                bit_index++;
                start_ms = t;
            }
        } else {
            sending = 0;
            box_on = 0;
            state = UI_TOKEN;
            strcpy(msg, "Ingrese TOKEN (6 digitos)");
        }
    }
}

// -------------------------------
// Maneja teclas
// -------------------------------
void keypress(Display *d, XKeyEvent *e) {
    KeySym ks = XLookupKeysym(e, 0);

    if (ks == XK_q || ks == XK_Q) exit(0);  // Salir

    if (ks == XK_Escape) {  // Reset a idle
        state = UI_IDLE;
        sending = 0;
        box_on = 0;
        bit_index = 0;
        tok_len = 0;
        token[0] = 0;
        strcpy(msg, "Presiona ENTER para enviar");
        return;
    }

    if (state == UI_IDLE && ks == XK_Return) {  // Iniciar envío
        prepare_tx();
    } else if (state == UI_TOKEN) {
        if (ks == XK_Return) {  // Validar token
            unsigned int t = (unsigned int)(time(NULL) / 30u);
            unsigned int valid[3] = {make_token(t-1), make_token(t), make_token(t+1)};
            unsigned int ent = atoi(token);
            strcpy(msg, (ent == valid[0] || ent == valid[1] || ent == valid[2]) ? "VALIDO ✅" : "NO VALIDO ❌");
            strcpy(msg + strlen(msg), " | ESC=reset, ENTER=reenviar");
            tok_len = 0;
            token[0] = 0;
            state = UI_IDLE;
        } else if ((ks >= XK_0 && ks <= XK_9) && tok_len < 6) {  // Digito
            token[tok_len++] = '0' + (ks - XK_0);
            token[tok_len] = 0;
        } else if (ks == XK_BackSpace && tok_len > 0) {  // Borrar
            token[--tok_len] = 0;
        }
    }
}

// -------------------------------
// Programa principal (bucle simplificado)
// -------------------------------
int main() {
    Display *d = XOpenDisplay(NULL);  // Abre display
    if (!d) {
        fprintf(stderr, "Error al abrir DISPLAY\n");
        return 1;
    }

    int s = DefaultScreen(d);  // Pantalla default
    Window w = XCreateSimpleWindow(d, RootWindow(d, s), 100, 100, WIN_W, WIN_H, 1, BlackPixel(d, s), BlackPixel(d, s));  // Crea ventana
    XSelectInput(d, w, ExposureMask | KeyPressMask);  // Eventos: expose y key
    XMapWindow(d, w);  // Muestra ventana
    GC gc = XCreateGC(d, w, 0, NULL);  // Contexto gráfico

    while (1) {  // Bucle principal
        while (XPending(d)) {  // Procesa eventos
            XEvent ev;
            XNextEvent(d, &ev);
            if (ev.type == Expose) draw(d, w, gc);  // Redibuja
            else if (ev.type == KeyPress) keypress(d, &ev.xkey);  // Tecla
        }
        if (sending) step_pattern();  // Avanza patrón si enviando
        draw(d, w, gc);  // Dibuja siempre
        usleep(16000);  // Espera 16ms para ~60fps
    }
    return 0;
}
