#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QKeyEvent>
#include <QTime>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void paintEvent(QPaintEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;   // ✅ Corregido

private slots:
    void updateFrame();

private:
    Ui::MainWindow *ui;
    QTimer *timer;

    // Variables del patrón
    unsigned int bits[32];
    int bit_index = 0;
    int sending = 0;
    int stage = 0;
    unsigned long start_ms = 0;
    bool box_on = false;

    enum State { UI_IDLE, UI_SENDING, UI_TOKEN } state;
    QString msg;
    QString token;
    int tok_len = 0;

    // Funciones auxiliares
    unsigned long now_ms();
    void int_to_bits(unsigned int val);
    unsigned int make_token(unsigned int t);
    void prepare_tx();
    void step_pattern();
};

#endif // MAINWINDOW_H
