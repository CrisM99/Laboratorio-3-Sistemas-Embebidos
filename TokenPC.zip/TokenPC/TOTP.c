#include "TOTP.h"


uint32_t generate_simple_totp(const char *simetrica, uint32_t time_step, uint32_t base) {

    uint32_t segundos = time_step - base;

    uint32_t time_counter = (base/30) + (segundos/30);

    uint32_t code;

    uint32_t A = *(simetrica) + *(simetrica + 3);

    uint32_t B = time_counter * 0xF;

    code = B * (A*A);

    code = code % 1000000;

    return code;
}

uint32_t cambiar_unix(uint32_t unix_base, long crono)
{
    long segundos = crono / 1000;

    uint32_t unix = unix_base + segundos;

    return unix;
}
