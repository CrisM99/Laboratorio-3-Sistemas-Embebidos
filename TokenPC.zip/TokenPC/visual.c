#include "visual.h"

void delay_ms(int milliseconds)
{
    clock_t start_time = clock();
    while (clock() < start_time + milliseconds * CLOCKS_PER_SEC / 1000);
}

void recuadro(uint8_t modo)
{
    uint8_t caracter;

    if(modo == 1)
    {
        caracter = 219;
    }else if(modo == 0) caracter = ' ';

    for(int y = 0; y < 5; y ++)
    {
        for(int x = 0; x < 10; x ++)
        {
            printf("%c", caracter);
        }
        printf("\n");
    }
}

void mostrar_stm(uint32_t tiempo)
{
    uint8_t bits[32];

    recuadro(1);

    delay_ms(960);

    system("cls");

    for (int i = 31; i >= 0; i--)
    {
        bits[i] = (tiempo >> i) & 1;

        if (bits[i])
            recuadro(1);      // blanco para 1
        else
            recuadro(0); // negro para 0

        printf("%i", i);

        delay_ms(960);

        system("cls");
    }
}
