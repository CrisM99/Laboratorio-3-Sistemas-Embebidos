#ifndef TOTP_H
#define TOTP_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint32_t generate_simple_totp(const char *secret, uint32_t unix, uint32_t unix0);

#ifdef __cplusplus
}
#endif

#endif // TOTP_H

