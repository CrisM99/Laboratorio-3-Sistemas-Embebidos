#ifndef VISUAL_H
#define VISUAL_H

#include "TOTP.h"

void mostrar_stm(uint32_t tiempo);

#endif // VISUAL_H
