#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QDateTime>

// -------------------------------
// Parámetros de ventana y recuadro
// -------------------------------
#define WIN_W 800
#define WIN_H 600
#define BOX_W 200
#define BOX_H 200
#define BOX_X (WIN_W - BOX_W - 20)
#define BOX_Y 20

// -------------------------------
// Tiempos
// -------------------------------
#define PULSE_SYNC 100
#define PULSE_BLINK 50
#define PULSE_BIT 100
#define PULSE_SEP 100

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    resize(WIN_W, WIN_H);

    state = UI_IDLE;
    msg = "Presiona ENTER para enviar";

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::updateFrame);
    timer->start(16); // ~60fps
}

MainWindow::~MainWindow() {
    delete ui;
}

unsigned long MainWindow::now_ms() {
    return QDateTime::currentMSecsSinceEpoch();
}

void MainWindow::int_to_bits(unsigned int val) {
    for (int i = 0; i < 32; i++) {
        bits[i] = (val >> (31 - i)) & 1;
    }
    bit_index = 0;
}

unsigned int MainWindow::make_token(unsigned int t) {
    unsigned int h = t ^ 0xA5A5A5A5u;
    h ^= (h >> 16);
    h *= 0x45d9f3bu;
    h ^= (h >> 16);
    h *= 0x45d9f3bu;
    h ^= (h >> 16);
    return h % 1000000u;
}

void MainWindow::prepare_tx() {
    unsigned int t = (unsigned int)(QDateTime::currentSecsSinceEpoch() / 30u);
    int_to_bits(t);
    sending = 1;
    stage = 0;
    start_ms = now_ms();
    box_on = false;
    msg = "Enviando...";
    state = UI_SENDING;
}

void MainWindow::step_pattern() {
    if (!sending) return;
    unsigned long t = now_ms();
    unsigned long elapsed = t - start_ms;

    if (stage == 0) {
        if (elapsed < PULSE_SYNC) {
            box_on = ((elapsed / PULSE_BLINK) % 2) == 0;
        } else {
            box_on = false;
            stage = 1;
            start_ms = t;
        }
    } else if (stage == 1) {
        if (bit_index < 32) {
            int bit = bits[bit_index];
            unsigned long pulse = bit ? PULSE_BIT : PULSE_BIT / 2;
            if (elapsed < pulse) {
                box_on = true;
            } else if (elapsed < pulse + PULSE_SEP) {
                box_on = false;
            } else {
                bit_index++;
                start_ms = t;
            }
        } else {
            sending = 0;
            box_on = false;
            state = UI_TOKEN;
            msg = "Ingrese TOKEN (6 digitos)";
        }
    }
}

void MainWindow::paintEvent(QPaintEvent * /*event*/) {
    QPainter p(this);
    p.fillRect(rect(), Qt::black);

    // Dibuja caja
    p.fillRect(BOX_X, BOX_Y, BOX_W, BOX_H, box_on ? Qt::white : Qt::black);

    // Mensajes
    p.setPen(Qt::green);
    p.drawText(20, 20, msg);

    if (state == UI_TOKEN) {
        p.drawText(20, 50, "TOKEN: " + token);
        p.drawText(20, 80, "6 digitos, ENTER=validar, ESC=reset");
    } else if (state == UI_IDLE) {
        p.drawText(20, 50, "ENTER=enviar | Q=salir");
    }
}

void MainWindow::keyPressEvent(QKeyEvent *event) {
    int key = event->key();

    if (key == Qt::Key_Q) qApp->exit();

    if (key == Qt::Key_Escape) {
        state = UI_IDLE;
        sending = 0;
        box_on = false;
        bit_index = 0;
        tok_len = 0;
        token.clear();
        msg = "Presiona ENTER para enviar";
        return;
    }

    if (state == UI_IDLE && key == Qt::Key_Return) {
        prepare_tx();
    } else if (state == UI_TOKEN) {
        if (key == Qt::Key_Return) {
            unsigned int t = (unsigned int)(QDateTime::currentSecsSinceEpoch() / 30u);
            unsigned int valid[3] = {make_token(t-1), make_token(t), make_token(t+1)};
            unsigned int ent = token.toUInt();
            msg = (ent == valid[0] || ent == valid[1] || ent == valid[2]) ? "VALIDO ✅" : "NO VALIDO ❌";
            msg += " | ESC=reset, ENTER=reenviar";
            tok_len = 0;
            token.clear();
            state = UI_IDLE;
        } else if (key >= Qt::Key_0 && key <= Qt::Key_9 && tok_len < 6) {
            token.append(QChar('0' + (key - Qt::Key_0)));
            tok_len++;
        } else if (key == Qt::Key_Backspace && tok_len > 0) {
            token.chop(1);
            tok_len--;
        }
    }
}

void MainWindow::updateFrame() {
    if (sending) step_pattern();
    update();
}
