#ifndef TOTP_H
#define TOTP_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <string.h>

uint32_t generate_simple_totp(const char *secret, uint32_t time_step, uint32_t base);

uint32_t cambiar_unix(uint32_t unix_base, long crono);

#endif // TOTP_H
