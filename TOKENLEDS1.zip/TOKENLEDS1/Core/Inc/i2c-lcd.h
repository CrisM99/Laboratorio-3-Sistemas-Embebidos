#ifndef I2C_LCD_H_
#define I2C_LCD_H_

#include "stm32f4xx_hal.h"  // o tu serie: stm32f4xx_hal.h, etc.
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ====== CONFIG ======
#ifndef LCD_I2C_ADDR
#define LCD_I2C_ADDR    (0x27 << 1)   // Cambia a (0x3F << 1) si tu backpack es 0x3F
#endif

// Tamaño del LCD (por defecto 16x2)
// Descomenta para 20x4
// #define LCD_20x4

#ifndef LCD_COLS
  #ifdef LCD_20x4
    #define LCD_COLS 20
    #define LCD_ROWS 4
  #else
    #define LCD_COLS 16
    #define LCD_ROWS 2
  #endif
#endif

// ====== API ======
void lcd_init(void);
void lcd_clear(void);
void lcd_put_cur(uint8_t row, uint8_t col);
void lcd_send_char(char ch);
void lcd_send_string(const char *str);

// Utilidades
void lcd_backlight_on(void);
void lcd_backlight_off(void);

#ifdef __cplusplus
}
#endif

#endif /* I2C_LCD_H_ */
