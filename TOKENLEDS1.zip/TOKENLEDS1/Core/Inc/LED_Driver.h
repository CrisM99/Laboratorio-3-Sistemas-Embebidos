/*
 * LED_Driver.h
 *
 *  Created on: Aug 21, 2025
 *      Author: User
 */

#ifndef INC_LED_DRIVER_H_
#define INC_LED_DRIVER_H_

#include "main.h"

void led_veces(uint32_t veces);

#endif /* INC_LED_DRIVER_H_ */
