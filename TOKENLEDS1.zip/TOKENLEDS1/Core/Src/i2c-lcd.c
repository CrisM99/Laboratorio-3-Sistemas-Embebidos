#include "i2c-lcd.h"
#include <string.h>

// Ajusta a tu handle I2C
extern I2C_HandleTypeDef hi2c1;
#define LCD_I2C_HANDLE hi2c1

// Mapeo de pines PCF8574 más común:
// P0=RS, P1=RW, P2=EN, P3=BL, P4=D4, P5=D5, P6=D6, P7=D7
#define LCD_RS          0x01
#define LCD_RW          0x02
#define LCD_EN          0x04
#define LCD_BACKLIGHT   0x08

static uint8_t lcd_backlight_state = LCD_BACKLIGHT;

// ---- Helpers ----
static void lcd_write_byte(uint8_t data) {
    HAL_I2C_Master_Transmit(&LCD_I2C_HANDLE, LCD_I2C_ADDR, &data, 1, HAL_MAX_DELAY);
}

static void lcd_pulse_enable(uint8_t data) {
    lcd_write_byte(data | LCD_EN);
    // EN high width > 450ns; 1ms es seguro
    HAL_Delay(1);
    lcd_write_byte(data & ~LCD_EN);
    HAL_Delay(1);
}

// nibble: debe venir en el nibble alto (bits 7..4)
// mode: 0 para comando, LCD_RS para dato
static void lcd_write_nibble(uint8_t nibble_hi, uint8_t mode) {
    uint8_t data = (nibble_hi & 0xF0) | lcd_backlight_state | (mode ? LCD_RS : 0x00);
    lcd_pulse_enable(data);
}

static void lcd_send_internal(uint8_t value, uint8_t mode) {
    // Enviar nibble alto luego nibble bajo
    lcd_write_nibble(value & 0xF0, mode);
    lcd_write_nibble((value << 4) & 0xF0, mode);
}

// ---- API ----
void lcd_backlight_on(void)  { lcd_backlight_state = LCD_BACKLIGHT; }
void lcd_backlight_off(void) { lcd_backlight_state = 0x00; }

void lcd_clear(void) {
    lcd_send_internal(0x01, 0); // CLEAR
    HAL_Delay(2);                // >1.52ms
}

void lcd_put_cur(uint8_t row, uint8_t col) {
#ifdef LCD_20x4
    static const uint8_t row_offsets[4] = {0x00, 0x40, 0x14, 0x54};
    if (row >= 4) row = 3;
#else
    static const uint8_t row_offsets[2] = {0x00, 0x40};
    if (row >= 2) row = 1;
#endif
    if (col >= LCD_COLS) col = LCD_COLS - 1;
    lcd_send_internal(0x80 | (row_offsets[row] + col), 0);
}

void lcd_send_char(char ch) {
    lcd_send_internal((uint8_t)ch, LCD_RS);
}

void lcd_send_string(const char *str) {
    while (*str) {
        lcd_send_char(*str++);
    }
}

void lcd_init(void) {
    // Tiempo de power-up
    HAL_Delay(50);

    // Poner RW=0 siempre (no lo usamos)
    // Secuencia de inicialización 8-bit -> 4-bit (nibbles altos directos)
    lcd_write_nibble(0x30, 0); HAL_Delay(5);
    lcd_write_nibble(0x30, 0); HAL_Delay(1);
    lcd_write_nibble(0x30, 0); HAL_Delay(1);
    lcd_write_nibble(0x20, 0); HAL_Delay(1); // 4-bit mode

    // Function set: 4-bit, 2 líneas, 5x8
#ifdef LCD_20x4
    lcd_send_internal(0x28, 0); // 4-bit, 2-line (controlador maneja 4 líneas con DDRAM especial)
#else
    lcd_send_internal(0x28, 0);
#endif

    // Display OFF
    lcd_send_internal(0x08, 0);

    // Clear
    lcd_clear();

    // Entry mode: incrementar, sin shift
    lcd_send_internal(0x06, 0);

    // Display ON, cursor OFF, blink OFF
    lcd_send_internal(0x0C, 0);

    // Backlight ON
    lcd_backlight_on();
}
