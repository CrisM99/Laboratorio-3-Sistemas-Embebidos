/*
 * LED_Driver.c
 *
 *  Created on: Aug 21, 2025
 *      Author: User
 */

#include "LED_Driver.h"

void led_on(void){
	HAL_GPIO_WritePin(GPIOC ,GPIO_PIN_13, 0);
}

void led_off(void){
	HAL_GPIO_WritePin(GPIOC ,GPIO_PIN_13, 1);
}

void led_veces(uint32_t veces){

	for(int i = 0; i < veces; i++){
		led_on();
		HAL_Delay(500);
		led_off();
		HAL_Delay(120);
	}

}






